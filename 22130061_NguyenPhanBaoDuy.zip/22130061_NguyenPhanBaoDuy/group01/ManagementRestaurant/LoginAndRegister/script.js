function register() {
    var username = document.getElementById("username").value;
    var email = document.getElementById("email").value;
    var password = document.getElementById("password").value;
    var confirmPassword = document.getElementById("confirmPassword").value;
    var acceptTerms = document.getElementById("acceptTerms").checked;

    if (password !== confirmPassword) {
        alert("Mật khẩu và xác nhận mật khẩu không khớp.");
        return false; // Chặn gửi form nếu có lỗi
    }

    if (!acceptTerms) {
        alert("Bạn cần chấp nhận các điều khoản.");
        return false; // Chặn gửi form nếu có lỗi
    }

    var user = {
        username: username,
        email: email,
        password: password
    };

    // Lấy danh sách người dùng từ Local Storage nếu có
    var users = JSON.parse(localStorage.getItem('registeredUsers')) || [];

    // Thêm người dùng mới vào danh sách
    users.push(user);

    // Lưu danh sách người dùng mới vào Local Storage
    localStorage.setItem('registeredUsers', JSON.stringify(users));

    // Reset các trường nhập và checkbox
    document.getElementById("username").value = "";
    document.getElementById("email").value = "";
    document.getElementById("password").value = "";
    document.getElementById("confirmPassword").value = "";
    document.getElementById("acceptTerms").checked = false;

    alert("Chúc mừng. Đăng ký thành công");
    window.location.href = 'login.html';

    return false;
}

function login() {
    var usernameOrEmail = document.getElementById("usernameOrEmail").value;
    var password = document.getElementById("password").value;

    // Lấy danh sách người dùng từ Local Storage
    var users = JSON.parse(localStorage.getItem('registeredUsers')) || [];

    // Kiểm tra thông tin đăng nhập với danh sách người dùng
    var loggedInUser = users.find(function(user) {
        return (user.username === usernameOrEmail || user.email === usernameOrEmail) && user.password === password;
    });

    if (loggedInUser) {
        alert("Đăng nhập thành công!");
        // Nếu thông tin đăng nhập đúng, có thể thực hiện các hành động khác ở đây (ví dụ: chuyển hướng trang, hiển thị nội dung...)
        
        // Chuyển hướng đến trang index.html nằm bên ngoài thư mục hiện tại
        window.location.href = "../index.html";
        return false; // Ngăn chặn gửi form và tránh tải lại trang
    }

    // Nếu không tìm thấy thông tin đăng nhập trong danh sách người dùng
    alert("Thông tin đăng nhập không chính xác. Vui lòng thử lại hoặc đăng ký nếu chưa có tài khoản.");
    
    return false; // Ngăn chặn gửi form và tránh tải lại trang
}